/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imagenfondo;

/**
 *
 * @author CHAPARRO
 */
public class ImagenFondo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        new Index().setVisible(true);
    }
//        jl1.setSize(btn_ventas.getWidth()*3, btn_ventas.getHeight());
//        
//        ImageIcon ii = new ImageIcon(getClass().getResource("/imagenes/matixayoutube.png"));
//        Icon i = new ImageIcon(ii.getImage().getScaledInstance(jl1.getWidth(), jl1.getHeight(), Image.SCALE_DEFAULT));
//
//        jl1.setIcon(i);      
    
}
